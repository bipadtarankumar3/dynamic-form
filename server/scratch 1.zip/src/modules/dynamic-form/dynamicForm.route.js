const express = require("express");
const dynamicFormController = require("./controller/dynamicForm.controller");
const {
  checkPermission,
  checkAnyPermission,
} = require("../../middlewares/checkPermission.middleware");
const sanitizeMiddleware = require("../../middlewares/sanitize.middleware");
const secureUpload = require("../../middlewares/secureUpload.middleware");
const { dynamicFormRL } = require("../../rate-limit/dynamicFormRL");
const router = express.Router();
const multer = require("multer")();

// Load Form-Specific Backend Hooks
require("./hooks/projectHooks");

router.post(
  "/add",
  dynamicFormRL,
  multer.any(),
  sanitizeMiddleware, secureUpload,
  checkPermission(undefined, "add"),
  dynamicFormController.add,
);
router.post(
  "/edit",
  dynamicFormRL,
  multer.any(),
  sanitizeMiddleware, secureUpload,
  checkPermission(undefined, "edit"),
  dynamicFormController.edit,
);
router.post(
  "/general-list-view",
  checkPermission(undefined, "list"),
  dynamicFormController.generalListView,
);
router.post(
  "/view-list-view",
  checkPermission(undefined, "list"),
  dynamicFormController.viewListView,
);
router.post(
  "/general-export-excel",
  checkPermission(undefined, "list"),
  dynamicFormController.generalExcelExport,
);
router.post(
  "/details",
  checkAnyPermission(undefined, ["view", "edit", "details", "read", "list"]),
  dynamicFormController.details,
);
router.post("/schema-details", dynamicFormController.schemaDetails);
router.post("/master-details", dynamicFormController.masterDetails);
router.post("/parent-record", dynamicFormController.parentRecord);
router.post(
  "/active_inactive",
  dynamicFormController.activeInactive,
);
router.post(
  "/view",
  dynamicFormController.viewById,
);

module.exports = router;
