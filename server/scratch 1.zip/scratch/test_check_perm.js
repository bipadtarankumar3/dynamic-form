require('dotenv').config();
const { sequelize } = require('../src/config/db.config');

async function testPerm() {
  const role_id = 6;
  const targetMod = "request_for_proposal";
  const targetAct = "view";
  const fullKey = `${targetMod}.${targetAct}`;

  const results = await sequelize.query(
    `
    SELECT p.id, p.module, p.key, p.type, rp.role_id
    FROM t_role_permissions rp
    JOIN t_permissions p ON rp.permission_id = p.id
    WHERE rp.role_id = :role_id
      AND (
        p.module = :mod_slug 
        OR p.module = REPLACE(:mod_slug, '_form', '')
        OR p.module = REPLACE(:mod_slug, 'frm_', '')
      )
      AND (
        p.type = :act_slug 
        OR p.key = :full_key 
        OR p.key = :act_slug
      )
      AND rp.deleted_at IS NULL
      AND p.deleted_at IS NULL
    LIMIT 1;
    `,
    {
      replacements: {
        role_id,
        mod_slug: targetMod,
        act_slug: targetAct,
        full_key: fullKey,
      },
      type: sequelize.QueryTypes.SELECT,
    }
  );

  console.log("Check permission test result:", results);
  process.exit(0);
}

testPerm().catch(err => {
  console.error("Test failed:", err);
  process.exit(1);
});
