require('dotenv').config();
const db = require('../src/config/db');

async function run() {
  // Ensure menu ID 20 (Request for Proposal) is parent_id: null
  await db.query(`UPDATE t_menus SET parent_id = NULL, label = 'Request for Proposal', is_active = TRUE, deleted_at = NULL WHERE id = 20`);

  // Check if sub-menu for RFP Proposal Submissions exists
  const sub = await db.query(`SELECT id FROM t_menus WHERE url LIKE '%rfp_proposal_submission%' AND deleted_at IS NULL`);
  if (sub.rows.length === 0) {
    await db.query(`
      INSERT INTO t_menus (parent_id, label, icon, url, "order", is_active, is_configurator, is_public, created_by, updated_by)
      VALUES (20, 'RFP Submissions & Ratings', 'FileTextOutlined', '/forms/rfp_proposal_submission', 2, TRUE, FALSE, FALSE, 1, 1)
    `);
  } else {
    await db.query(`
      UPDATE t_menus SET parent_id = 20, label = 'RFP Submissions & Ratings', is_active = TRUE, deleted_at = NULL WHERE id = $1
    `, [sub.rows[0].id]);
  }

  console.log('RFP menus configured cleanly!');
  process.exit(0);
}

run().catch(err => {
  console.error(err);
  process.exit(1);
});
