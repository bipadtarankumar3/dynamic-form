require('dotenv').config();
const db = require('../src/config/db');

async function run() {
  console.log("Setting up t_frm_rfp_float table...");

  await db.query(`
    CREATE SEQUENCE IF NOT EXISTS t_frm_rfp_float_id_seq;

    CREATE TABLE IF NOT EXISTS public.t_frm_rfp_float
    (
        id integer NOT NULL DEFAULT nextval('t_frm_rfp_float_id_seq'::regclass),
        parent_id integer,
        float_date date DEFAULT CURRENT_DATE,
        remarks text,
        ngo jsonb,
        status text DEFAULT 'floated',
        created_by integer,
        updated_by integer,
        created_at timestamp with time zone DEFAULT now(),
        updated_at timestamp with time zone DEFAULT now(),
        deleted_at timestamp with time zone,
        name_ngo jsonb,
        CONSTRAINT t_frm_rfp_float_pkey PRIMARY KEY (id),
        CONSTRAINT fk_t_frm_rfp_float_parent FOREIGN KEY (parent_id)
            REFERENCES public.t_frm_request_for_proposal (id) MATCH SIMPLE
            ON UPDATE NO ACTION
            ON DELETE CASCADE
    );
  `);

  console.log("t_frm_rfp_float table created successfully!");
  process.exit(0);
}

run().catch(err => {
  console.error("Setup t_frm_rfp_float failed:", err);
  process.exit(1);
});
