require('dotenv').config();
const db = require('../src/config/db');

async function restore() {
  console.log("Restoring request_for_proposal permissions for NGO role (role_id = 6)...");

  // Restore deleted_at = NULL in t_role_permissions for role_id 6 and module request_for_proposal
  const res = await db.query(`
    UPDATE t_role_permissions rp
    SET deleted_at = NULL, updated_at = NOW()
    FROM t_permissions p
    WHERE p.id = rp.permission_id
      AND rp.role_id = 6
      AND (p.module = 'request_for_proposal' OR p.key LIKE 'request_for_proposal%')
  `);

  console.log(`Updated ${res.rowCount} role permissions rows setting deleted_at = NULL!`);

  // Verify active perms for role 6
  const activePerms = await db.query(`
    SELECT rp.id, rp.role_id, p.module, p.key, p.type, rp.deleted_at
    FROM t_role_permissions rp
    JOIN t_permissions p ON p.id = rp.permission_id
    WHERE rp.role_id = 6 AND rp.deleted_at IS NULL
      AND (p.module = 'request_for_proposal' OR p.key LIKE 'request_for_proposal%')
  `);

  console.log("Active permissions for request_for_proposal (role 6):", activePerms.rows);
  process.exit(0);
}

restore().catch(err => {
  console.error("Restore failed:", err);
  process.exit(1);
});
