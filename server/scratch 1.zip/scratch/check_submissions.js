require('dotenv').config();
const db = require('../src/config/db');

async function check() {
  const subCols = await db.query(`
    SELECT column_name, data_type 
    FROM information_schema.columns 
    WHERE table_name = 't_frm_rfp_proposal_submission'
  `);
  console.log("t_frm_rfp_proposal_submission columns:", subCols.rows);

  const subData = await db.query(`SELECT * FROM t_frm_rfp_proposal_submission LIMIT 10`);
  console.log("t_frm_rfp_proposal_submission data:", subData.rows);

  process.exit(0);
}

check().catch(err => {
  console.error("Check failed:", err);
  process.exit(1);
});
