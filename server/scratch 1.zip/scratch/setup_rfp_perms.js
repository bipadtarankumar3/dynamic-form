require('dotenv').config();
const db = require('../src/config/db');

async function run() {
  const pNGO = [167, 541, 177, 179, 548];
  const pAdmin = [167, 169, 171, 173, 175, 541, 177, 179, 181, 183, 185, 548];

  for (const pid of pNGO) {
    const res = await db.query(
      'SELECT id FROM t_role_permissions WHERE role_id = $1 AND permission_id = $2 AND deleted_at IS NULL',
      [6, pid]
    );
    if (res.rows.length === 0) {
      await db.query(
        'INSERT INTO t_role_permissions (role_id, permission_id, created_by, updated_by) VALUES ($1, $2, 1, 1)',
        [6, pid]
      );
    }
  }

  for (const pid of pAdmin) {
    const res = await db.query(
      'SELECT id FROM t_role_permissions WHERE role_id = $1 AND permission_id = $2 AND deleted_at IS NULL',
      [2, pid]
    );
    if (res.rows.length === 0) {
      await db.query(
        'INSERT INTO t_role_permissions (role_id, permission_id, created_by, updated_by) VALUES ($1, $2, 1, 1)',
        [2, pid]
      );
    }
  }

  console.log('NGO and Admin permissions configured cleanly!');
  process.exit(0);
}

run().catch(err => {
  console.error(err);
  process.exit(1);
});
