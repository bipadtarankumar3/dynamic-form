require('dotenv').config();
const db = require('../src/config/db');

async function run() {
  console.log("Starting RFP Database Migration & Permissions Setup...");

  // 1. Ensure columns exist on t_frm_request_for_proposal
  await db.query(`
    ALTER TABLE t_frm_request_for_proposal
    ADD COLUMN IF NOT EXISTS floated_ngos JSONB DEFAULT '[]'::jsonb,
    ADD COLUMN IF NOT EXISTS evaluation_criteria JSONB DEFAULT '[]'::jsonb,
    ADD COLUMN IF NOT EXISTS status VARCHAR(50) DEFAULT 'Draft';
  `);
  console.log("Updated t_frm_request_for_proposal table columns!");

  // 2. Ensure columns exist on t_frm_rfp_proposal_submission & t_frm_partner_due_dilligence
  await db.query(`
    CREATE TABLE IF NOT EXISTS t_frm_rfp_proposal_submission (
      id SERIAL PRIMARY KEY,
      rfp_id INT,
      ngo_id INT,
      organization_name VARCHAR(255),
      email VARCHAR(255),
      project_title VARCHAR(255),
      proposed_budget NUMERIC,
      proposal_summary TEXT,
      rating NUMERIC DEFAULT 0,
      criteria_scores JSONB DEFAULT '{}'::jsonb,
      evaluation_notes TEXT,
      final_status VARCHAR(50) DEFAULT 'Submitted',
      created_by INT,
      updated_by INT,
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW(),
      deleted_at TIMESTAMP
    );

    ALTER TABLE t_frm_partner_due_dilligence
    ADD COLUMN IF NOT EXISTS rfp_id INT,
    ADD COLUMN IF NOT EXISTS rating NUMERIC DEFAULT 0,
    ADD COLUMN IF NOT EXISTS criteria_scores JSONB DEFAULT '{}'::jsonb,
    ADD COLUMN IF NOT EXISTS evaluation_notes TEXT,
    ADD COLUMN IF NOT EXISTS final_status VARCHAR(50) DEFAULT 'Submitted';
  `);
  console.log("Updated submission & due diligence table columns!");

  // 3. Ensure NGO Role & Permissions for RFP Lists Menu
  const ngoRoleRes = await db.query(`SELECT id FROM t_roles WHERE slug = 'ngo' AND deleted_at IS NULL LIMIT 1`);
  let ngoRoleId = 6;
  if (ngoRoleRes.rows.length > 0) {
    ngoRoleId = ngoRoleRes.rows[0].id;
  }

  // Ensure Menu Entry
  let menuRes = await db.query(`SELECT id FROM t_menus WHERE url LIKE '%rfp_proposal_submission%' AND deleted_at IS NULL LIMIT 1`);
  let menuId;
  if (menuRes.rows.length === 0) {
    const newMenu = await db.query(`
      INSERT INTO t_menus (parent_id, label, icon, url, "order", is_active, is_configurator, is_public, created_by, updated_by)
      VALUES (NULL, 'Assigned RFPs', 'FileTextOutlined', '/forms/rfp_proposal_submission', 7, TRUE, FALSE, FALSE, 1, 1)
      RETURNING id
    `);
    menuId = newMenu.rows[0].id;
  } else {
    menuId = menuRes.rows[0].id;
    await db.query(`
      UPDATE t_menus
      SET label = 'Assigned RFPs', is_active = TRUE, deleted_at = NULL
      WHERE id = $1
    `, [menuId]);
  }

  // Ensure permissions linked to NGO role
  const permissionsToGrant = [167, 541, 177, 179, 548];
  for (const pid of permissionsToGrant) {
    await db.query(`
      INSERT INTO t_role_permissions (role_id, permission_id, created_by, updated_by)
      VALUES ($1, $2, 1, 1)
      ON CONFLICT DO NOTHING
    `, [ngoRoleId, pid]);
  }

  console.log("RFP setup completed successfully!");
  process.exit(0);
}

run().catch(err => {
  console.error("Setup script failed:", err);
  process.exit(1);
});
