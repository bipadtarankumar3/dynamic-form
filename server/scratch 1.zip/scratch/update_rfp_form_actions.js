require('dotenv').config();
const db = require('../src/config/db');

async function run() {
  const res = await db.query(`SELECT actions FROM t_form WHERE slug = 'request_for_proposal'`);
  if (res.rows.length === 0) return;

  const actions = res.rows[0].actions || [];
  const updatedActions = actions.map(act => {
    if (act.slug === 'rfp_proposal_submission') {
      return {
        ...act,
        name: 'Apply RFP / Submit Proposal',
        roles: ['admin', 'ngo', 'user', 'manager']
      };
    }
    return act;
  });

  await db.query(`UPDATE t_form SET actions = $1 WHERE slug = 'request_for_proposal'`, [JSON.stringify(updatedActions)]);
  console.log('Updated actions for request_for_proposal in t_form!');
  process.exit(0);
}

run().catch(err => {
  console.error(err);
  process.exit(1);
});
