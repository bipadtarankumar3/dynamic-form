require('dotenv').config();
const db = require('../src/config/db');

async function grantPermissions() {
  console.log("Granting request_for_proposal permissions to NGO role (role_id = 6)...");

  // 1. Check columns of t_permissions
  const cols = await db.query(`
    SELECT column_name FROM information_schema.columns WHERE table_name = 't_permissions'
  `);
  console.log("t_permissions columns:", cols.rows.map(c => c.column_name));

  // 2. Fetch existing perms for request_for_proposal
  let permRes = await db.query(`
    SELECT id, module, key, type FROM t_permissions 
    WHERE module = 'request_for_proposal' OR key LIKE 'request_for_proposal%'
  `);

  if (permRes.rows.length === 0) {
    await db.query(`
      INSERT INTO t_permissions (module, key, type)
      VALUES 
        ('request_for_proposal', 'request_for_proposal.view', 'view'),
        ('request_for_proposal', 'request_for_proposal.list', 'list')
    `);
    permRes = await db.query(`
      SELECT id, module, key, type FROM t_permissions 
      WHERE module = 'request_for_proposal' OR key LIKE 'request_for_proposal%'
    `);
  }

  console.log("Found request_for_proposal perms:", permRes.rows);

  // Grant to role_id = 6
  const permIds = permRes.rows.map(p => p.id);
  for (const pid of permIds) {
    await db.query(`
      INSERT INTO t_role_permissions (role_id, permission_id, created_at, updated_at)
      VALUES (6, $1, NOW(), NOW())
      ON CONFLICT DO NOTHING;
    `, [pid]);
  }

  console.log("Granted all request_for_proposal perms to role_id 6 successfully!");
  process.exit(0);
}

grantPermissions().catch(err => {
  console.error("Failed:", err);
  process.exit(1);
});
