require('dotenv').config();
const db = require('../src/config/db');

async function check() {
  // 1. Check all NGO users and their role_id
  const users = await db.query(`
    SELECT u.id, u.name, u.email, u.role_id, u.role_slug
    FROM t_users u
    WHERE u.role_slug = 'ngo' OR LOWER(u.email) LIKE '%ngo%' OR u.id = 3
  `);
  console.log("NGO users and their role_id:", users.rows);

  // 2. Check t_role_permissions for request_for_proposal across ALL roles
  const rolePerms = await db.query(`
    SELECT rp.role_id, p.module, p.key, p.type
    FROM t_role_permissions rp
    JOIN t_permissions p ON p.id = rp.permission_id
    WHERE p.module = 'request_for_proposal' OR p.key LIKE '%request_for_proposal%'
  `);
  console.log("All role permissions for request_for_proposal:", rolePerms.rows);

  // 3. Grant view/list permissions for request_for_proposal to ALL roles associated with NGO users
  const roleIds = users.rows.map(u => u.role_id).filter(Boolean);
  roleIds.push(6); // Default NGO role id
  const uniqueRoleIds = [...new Set(roleIds)];

  const perms = await db.query(`
    SELECT id FROM t_permissions WHERE module = 'request_for_proposal'
  `);

  for (const rid of uniqueRoleIds) {
    for (const p of perms.rows) {
      await db.query(`
        INSERT INTO t_role_permissions (role_id, permission_id, created_at, updated_at)
        VALUES ($1, $2, NOW(), NOW())
        ON CONFLICT DO NOTHING;
      `, [rid, p.id]);
    }
  }
  console.log(`Granted permissions to role IDs: ${uniqueRoleIds.join(', ')}`);

  process.exit(0);
}

check().catch(err => {
  console.error("Check failed:", err);
  process.exit(1);
});
