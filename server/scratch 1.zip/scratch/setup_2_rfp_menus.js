require('dotenv').config();
const db = require('../src/config/db');

async function run() {
  // Menu 1: Request for Proposal (Admin CRUD & Rating) -> parent_id: NULL
  await db.query(`
    UPDATE t_menus
    SET parent_id = NULL, label = 'Request for Proposal', url = '/forms/request_for_proposal', is_active = TRUE, is_public = FALSE, deleted_at = NULL
    WHERE id = 20 OR url LIKE '%request_for_proposal%'
  `);

  // Menu 2: RFP Lists (NGO / Public RFP Listing & Proposal Submission) -> parent_id: NULL
  const rfpListSub = await db.query(`SELECT id FROM t_menus WHERE url LIKE '%rfp_proposal_submission%' AND deleted_at IS NULL`);
  if (rfpListSub.rows.length === 0) {
    await db.query(`
      INSERT INTO t_menus (parent_id, label, icon, url, "order", is_active, is_configurator, is_public, created_by, updated_by)
      VALUES (NULL, 'RFP Lists', 'FileTextOutlined', '/forms/rfp_proposal_submission', 7, TRUE, FALSE, FALSE, 1, 1)
    `);
  } else {
    await db.query(`
      UPDATE t_menus
      SET parent_id = NULL, label = 'RFP Lists', url = '/forms/rfp_proposal_submission', is_active = TRUE, is_public = FALSE, deleted_at = NULL
      WHERE id = $1
    `, [rfpListSub.rows[0].id]);
  }

  // Ensure role permissions for NGO (role_id 6) & Admin (role_id 2)
  const pNGO = [167, 541, 177, 179, 548];
  const pAdmin = [167, 169, 171, 173, 175, 541, 177, 179, 181, 183, 185, 548];

  for (const pid of pNGO) {
    const res = await db.query(
      'SELECT id FROM t_role_permissions WHERE role_id = $1 AND permission_id = $2 AND deleted_at IS NULL',
      [6, pid]
    );
    if (res.rows.length === 0) {
      await db.query(
        'INSERT INTO t_role_permissions (role_id, permission_id, created_by, updated_by) VALUES ($1, $2, 1, 1)',
        [6, pid]
      );
    }
  }

  for (const pid of pAdmin) {
    const res = await db.query(
      'SELECT id FROM t_role_permissions WHERE role_id = $1 AND permission_id = $2 AND deleted_at IS NULL',
      [2, pid]
    );
    if (res.rows.length === 0) {
      await db.query(
        'INSERT INTO t_role_permissions (role_id, permission_id, created_by, updated_by) VALUES ($1, $2, 1, 1)',
        [2, pid]
      );
    }
  }

  console.log('2 Standalone RFP Menus and Role Permissions created successfully!');
  process.exit(0);
}

run().catch(err => {
  console.error(err);
  process.exit(1);
});
