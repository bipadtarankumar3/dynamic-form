require('dotenv').config();
const db = require('../src/config/db');

async function debugPerm() {
  const perm = await db.query(`
    SELECT * FROM t_permissions WHERE key = 'request_for_proposal.view' OR module = 'request_for_proposal'
  `);
  console.log("t_permissions rows for request_for_proposal:", perm.rows);

  const rolePerm = await db.query(`
    SELECT rp.*, p.module, p.key, p.type
    FROM t_role_permissions rp
    JOIN t_permissions p ON p.id = rp.permission_id
    WHERE rp.role_id = 6
  `);
  console.log("t_role_permissions rows for role 6:", rolePerm.rows);

  process.exit(0);
}

debugPerm().catch(err => {
  console.error(err);
  process.exit(1);
});
