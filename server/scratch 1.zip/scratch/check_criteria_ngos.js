require('dotenv').config();
const db = require('../src/config/db');

async function check() {
  // 1. Check all NGO users from t_users
  const ngoUsers = await db.query(`
    SELECT u.id AS user_id, u.name, u.email, u.role_id, u.role_slug
    FROM t_users u
    WHERE u.deleted_at IS NULL
      AND (
        u.role_slug = 'ngo' 
        OR LOWER(u.department) LIKE '%ngo%'
        OR LOWER(u.designation) LIKE '%ngo%'
        OR u.role_id = 6
      )
    ORDER BY u.name ASC
  `);
  console.log(`Found ${ngoUsers.rows.length} NGO users in t_users:`);
  console.log(ngoUsers.rows);

  // Check columns of t_frm_criteria
  const cols = await db.query(`
    SELECT column_name, data_type 
    FROM information_schema.columns 
    WHERE table_name = 't_frm_criteria'
  `);
  console.log("Columns of t_frm_criteria:", cols.rows);

  if (cols.rows.length === 0) {
    await db.query(`
      CREATE TABLE IF NOT EXISTS t_frm_criteria (
        id SERIAL PRIMARY KEY,
        criteria_name VARCHAR(255),
        title VARCHAR(255),
        weightage NUMERIC DEFAULT 0,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT NOW(),
        deleted_at TIMESTAMP
      );
    `);
  }

  // Get data from t_frm_criteria
  const criteriaData = await db.query(`SELECT * FROM t_frm_criteria LIMIT 50`);
  console.log("Criteria data:", criteriaData.rows);

  process.exit(0);
}

check().catch(err => {
  console.error("Check failed:", err);
  process.exit(1);
});
