require('dotenv').config();
const db = require('../src/config/db');

async function testFetchCriteria(rfpId = 1) {
  // Query child criteria table for RFP
  const childRes = await db.query(`
    SELECT 
      c_child.id AS child_id,
      c_child.parent_id,
      c_child.request_criteria,
      c_child.weight,
      c_master.criteria_name,
      c_master.id AS master_id
    FROM t_frm_request_for_proposal_criteria c_child
    LEFT JOIN t_frm_criteria c_master ON c_master.id::text = c_child.request_criteria::text
    WHERE c_child.parent_id = $1 AND c_child.deleted_at IS NULL
    ORDER BY c_child.id ASC
  `, [rfpId]);

  console.log("RFP Child Criteria join result:", childRes.rows);
  process.exit(0);
}

testFetchCriteria(1).catch(e => { console.error(e); process.exit(1); });
