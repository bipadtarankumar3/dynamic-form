require('dotenv').config();
const db = require('../src/config/db');

async function checkTableCols() {
  const res = await db.query(`
    SELECT column_name FROM information_schema.columns
    WHERE table_name = 't_frm_rfp_proposal_submission'
    ORDER BY ordinal_position
  `);
  console.log("t_frm_rfp_proposal_submission columns:", res.rows.map(r => r.column_name));

  const sample = await db.query(`SELECT * FROM t_frm_rfp_proposal_submission LIMIT 5`);
  console.log("Sample rows:", JSON.stringify(sample.rows, null, 2));
  process.exit(0);
}
checkTableCols().catch(e => { console.error(e); process.exit(1); });
