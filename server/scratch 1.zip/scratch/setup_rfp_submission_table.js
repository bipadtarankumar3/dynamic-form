require('dotenv').config();
const db = require('../src/config/db');

async function setupTable() {
  console.log("Ensuring t_frm_rfp_proposal_submission table exists with all required fields...");

  await db.query(`
    CREATE SEQUENCE IF NOT EXISTS t_frm_rfp_proposal_submission_id_seq;

    CREATE TABLE IF NOT EXISTS public.t_frm_rfp_proposal_submission (
      id integer NOT NULL DEFAULT nextval('t_frm_rfp_proposal_submission_id_seq'::regclass),
      parent_id integer,
      organization_profile text,
      project_understanding text,
      methodology text,
      team text,
      implementation_plan text,
      risk_plan text,
      budget text,
      timeline text,
      sustainability text,
      monitoring_framework text,
      proposal_pdf text,
      budget_excel text,
      team_cvs text,
      previous_experience text,
      case_studies text,
      status text DEFAULT 'Submitted',
      rating numeric DEFAULT 0,
      criteria_scores jsonb DEFAULT '[]'::jsonb,
      evaluation_notes text,
      final_status text DEFAULT 'Submitted',
      created_by integer,
      updated_by integer,
      created_at timestamp with time zone DEFAULT now(),
      updated_at timestamp with time zone DEFAULT now(),
      deleted_at timestamp with time zone,
      CONSTRAINT t_frm_rfp_proposal_submission_pkey PRIMARY KEY (id),
      CONSTRAINT fk_rfp_submission_parent FOREIGN KEY (parent_id)
        REFERENCES public.t_frm_request_for_proposal (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE
    );
  `);

  // Ensure any missing columns exist via ALTER TABLE
  const columnsToAdd = [
    'organization_profile', 'project_understanding', 'methodology', 'team',
    'implementation_plan', 'risk_plan', 'budget', 'timeline', 'sustainability',
    'monitoring_framework', 'proposal_pdf', 'budget_excel', 'team_cvs',
    'previous_experience', 'case_studies', 'status', 'rating', 'criteria_scores',
    'evaluation_notes', 'final_status'
  ];

  for (const col of columnsToAdd) {
    try {
      const type = (col === 'rating') ? 'numeric DEFAULT 0' : (col === 'criteria_scores') ? "jsonb DEFAULT '[]'::jsonb" : 'text';
      await db.query(`ALTER TABLE public.t_frm_rfp_proposal_submission ADD COLUMN IF NOT EXISTS ${col} ${type};`);
    } catch (e) {
      console.log(`Column ${col} check:`, e.message);
    }
  }

  console.log("t_frm_rfp_proposal_submission setup verified!");
  process.exit(0);
}

setupTable().catch(err => {
  console.error("Setup failed:", err);
  process.exit(1);
});
