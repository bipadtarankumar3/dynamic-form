require('dotenv').config();
const db = require('../src/config/db');

async function checkCriteria() {
  // 1. Check t_frm_request_for_proposal columns & sample data
  const rfpRes = await db.query(`SELECT id, rfp_information, project_details, evaluation_criteria, floated_ngos FROM t_frm_request_for_proposal LIMIT 5`);
  console.log("RFP sample evaluation_criteria:", rfpRes.rows);

  // 2. Check if there is a child criteria table for request_for_proposal
  const tables = await db.query(`
    SELECT table_name FROM information_schema.tables 
    WHERE table_schema = 'public' AND table_name LIKE '%criteria%'
  `);
  console.log("Criteria tables in DB:", tables.rows.map(t => t.table_name));

  // 3. Check sample rows from any criteria table
  for (const t of tables.rows) {
    const rows = await db.query(`SELECT * FROM ${t.table_name} LIMIT 5`);
    console.log(`Table ${t.table_name} sample rows:`, rows.rows);
  }

  process.exit(0);
}

checkCriteria().catch(e => { console.error(e); process.exit(1); });
